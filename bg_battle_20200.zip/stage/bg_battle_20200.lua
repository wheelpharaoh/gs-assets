if not LWF then LWF={} end
if not LWF.Script then LWF.Script={} end
if not LWF.Script.bg_battle_20200 then LWF.Script.bg_battle_20200={} end

LWF.Script.bg_battle_20200.nami_1_anim_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*100)+1))
end

LWF.Script.bg_battle_20200.nami_1_brend_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*15)+1))
end

LWF.Script.bg_battle_20200.uti0_p_anim2_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*200)+100))
end

LWF.Script.bg_battle_20200.uti0_p_anim_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*200)+90))
end

LWF.Script.bg_battle_20200.uti1_p_anim2_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*70)+90))
end

LWF.Script.bg_battle_20200.uti1_p_anim_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*70)+90))
end

LWF.Script.bg_battle_20200.uti2_p_anim2_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*200)+200))
end

LWF.Script.bg_battle_20200.uti2_p_anim_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*200)+90))
end

LWF.Script.bg_battle_20200.uti2shadow_p_anim_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*200)+90))
end

LWF.Script.bg_battle_20200.uti3_p_anim2_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*70)+125))
end

LWF.Script.bg_battle_20200.uti3_p_anim_0_1 = function(self)
	local _root = self.lwf._root

	self:gotoAndPlay(math.floor((math.random()*85)+120))
end
