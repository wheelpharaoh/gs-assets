if not LWF then LWF={} end
if not LWF.Script then LWF.Script={} end
if not LWF.Script.bg_battle_2008910 then LWF.Script.bg_battle_2008910={} end

LWF.Script.bg_battle_2008910._tree_animations_tree1Animation_39_2 = function(self)
	local _root = self.lwf._root

	self:stop();
end

LWF.Script.bg_battle_2008910._tree_animations_tree2Animation_39_1 = function(self)
	local _root = self.lwf._root

	self:stop();
end

LWF.Script.bg_battle_2008910._tree_animations_treeFrontAnimation1_29_2 = function(self)
	local _root = self.lwf._root

	self:stop();
end

LWF.Script.bg_battle_2008910._tree_animations_treeFrontAnimation2_29_1 = function(self)
	local _root = self.lwf._root

	self:stop();
end
