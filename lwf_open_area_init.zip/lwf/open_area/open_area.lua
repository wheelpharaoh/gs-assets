if not LWF then LWF={} end
if not LWF.Script then LWF.Script={} end
if not LWF.Script.open_area then LWF.Script.open_area={} end

LWF.Script.open_area._root_0_1 = function(self)
	local _root = self.lwf._root

	playSound("SE_SYSTEM_047_OPEN_AREA")
end
